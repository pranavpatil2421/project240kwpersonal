# routes.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from core.database import get_db
from . import services, schemas
from modules.calibration_request.models import CalibrationRequest


router = APIRouter(prefix="/calibration-request", tags=["Calibration Request"])

@router.get("/{{prefix}_request_id}")
def get_request(calibration_request_id: int, db: Session = Depends(get_db)):
    req = db.query(CalibrationRequest).filter(
        CalibrationRequest.id == calibration_request_id
    ).first()

    if not req:
        raise HTTPException(status_code=404, detail="Not found")

    return {"id": req.id, "status": req.status}

@router.post("/")
def start_calibration_request(db: Session = Depends(get_db)):
    return services.create_calibration_request(db)


@router.post("/{{prefix}_request_id}/product")
def save_product(
    calibration_request_id: int,
    payload: schemas.CalibrationProductDetailsSchema,
    db: Session = Depends(get_db)
):
    services.save_calibration_product_details(db, calibration_request_id, payload)
    return {"status": "saved"}

@router.post("/{{prefix}_request_id}/documents")
def save_documents(
    calibration_request_id: int,
    payload: schemas.CalibrationTechnicalDocumentsSchema,
    db: Session = Depends(get_db)
):
    services.save_calibration_technical_documents(
        db,
        calibration_request_id,
        payload.documents
    )
    return {"status": "documents saved"}

@router.post("/{{prefix}_request_id}/requirements")
def save_requirements(
    calibration_request_id: int,
    payload: schemas.CalibrationRequirementsSchema,
    db: Session = Depends(get_db)
):
    services.save_calibration_requirements(db, calibration_request_id, payload)
    return {"status": "saved"}


@router.post("/{{prefix}_request_id}/standards")
def save_standards(
    calibration_request_id: int,
    payload: schemas.CalibrationStandardsSchema,
    db: Session = Depends(get_db)
):
    services.save_calibration_standards(db, calibration_request_id, payload)
    return {"status": "saved"}


@router.post("/{{prefix}_request_id}/lab-selection/draft")
def save_lab_selection_draft(
    calibration_request_id: int,
    payload: schemas.CalibrationLabSelectionSchema,
    db: Session = Depends(get_db)
):
    """Save lab selection as draft"""
    services.save_calibration_lab_selection_draft(db, calibration_request_id, payload)
    return {"status": "draft saved"}

@router.post("/{{prefix}_request_id}/submit")
def submit(
    calibration_request_id: int,
    payload: schemas.CalibrationLabSelectionSchema,
    db: Session = Depends(get_db)
):
    services.submit_calibration_request(db, calibration_request_id, payload)
    return {"status": "submitted"}


@router.get("/{{prefix}_request_id}/full")
def get_full_request(
    calibration_request_id: int,
    db: Session = Depends(get_db)
):
    data = services.get_full_calibration_request(db, calibration_request_id)

    if not data:
        raise HTTPException(status_code=404, detail="Calibration request not found")

    return data
